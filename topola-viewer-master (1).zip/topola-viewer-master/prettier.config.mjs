const config = {
  bracketSpacing: false,
  endOfLine: 'lf',
  singleQuote: true,
  plugins: ['prettier-plugin-organize-imports'],
};

export default config;
