/** No-op function for analytics. */
export function analyticsEvent(action: string, data?: any) { }
