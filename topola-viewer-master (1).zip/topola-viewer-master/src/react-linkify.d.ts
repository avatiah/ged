declare module 'react-linkify' {
  export default class Linkify extends React.Component<any, any> {}
}
