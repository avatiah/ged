// Data type definitions for the family-chart library.
declare module 'family-chart' {
  export function createStore(args: any): any;
  export function createSvg(args: any): any;
  export function view(arg1: any, arg2: any, arg3: any, arg4: any): any;
  export const elements: any;
}
