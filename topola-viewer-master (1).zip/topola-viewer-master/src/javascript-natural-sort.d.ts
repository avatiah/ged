// Data type definitions for the javascript-natural-sort library.
declare module 'javascript-natural-sort' {
  export default function naturalSort(a: string, b: string): number;
}
